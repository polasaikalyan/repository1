﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using RepositorySystem.Models;
using PagedList;
using PagedList.Mvc;

namespace RepositorySystem.Controllers
{
    public class StudentController : Controller
    {

        Training_20March_CloudChennaiEntities4 db = new Training_20March_CloudChennaiEntities4();
        public ActionResult StudentRoles()
        {
            return View();
        }

        // GET: Login
        public ActionResult StudentLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult StudentLogin(StudentDetail sd)
        {
            StudentDetail StudentExists = db.StudentDetails.Where(x => x.Username == sd.Username).SingleOrDefault();
            if (ModelState.ContainsKey("Password"))
                ModelState["Password"].Errors.Clear();
            if (StudentExists != null)
            {
                if (StudentExists.Password == sd.Password)               
                {
                    Session["Username"] = StudentExists.Username.ToString();
                    Session["role"] = "student";
                    return RedirectToAction("StudentRoles");
                }
                else
                {

                    ModelState.AddModelError("Password", "password incorrect");
                }
            }
            else
            {

                ModelState.AddModelError("Username", "Invalid Username");
            }
            return View();
        }

        public ActionResult StudentRegister()
        {
            return View();
        }

        [HttpPost]
        public ActionResult StudentRegister(StudentDetail student)
        {           
            if (ModelState.IsValid)    
            {

                    db.StudentDetails.Add(student);                   
                    db.SaveChanges();                                 
                return Content("<html><body><script>alert('Successfully Registered'); window.location.href = '/Student/StudentLogin';</script></body></html>");
                //return Content("<html><body>alert('Successfully Registered'); window.location.href = '/Student/StudentLogin';</body></html>");
            }        
            return View(student);
        }

        public ActionResult ViewJobs(int? page)
        {
            List<Job> li = db.Jobs.ToList();
            return View(li.ToList().ToPagedList(page ?? 1, 3));
        }
        public ActionResult jobForm(int? id)
        {
            var job = db.Jobs.Find(id);
            return View(job);
        }
        public JsonResult GetDetailsByUsername(string UserName)
        {
            string user = Session["Username"].ToString();
            if (UserName.ToLower() == user.ToLower())
            {
                var studentdetails = db.StudentDetails.Where(a => a.Username == UserName).SingleOrDefault();
                //return Json(new { data=studentdetails }, JsonRequestBehavior.AllowGet);
                return Json(new { status = "success", studentname = studentdetails.StudentName, emailId = studentdetails.EmailId, PhoneNumber = studentdetails.PhoneNumber, address = studentdetails.Address, DOB = studentdetails.DOB, Gender = studentdetails.Gender, HighSchoolMarks = studentdetails.HighSchoolMarks, IntermediateMarks = studentdetails.IntermediateMarks, GraduationCourse = studentdetails.GraduationCourse, GraduationPercentage = studentdetails.GraduationPercentage }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new { status = "error", msg = "Enter correct Username" }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult Savejobdetails(string Username, int? JobId)
        {
            var isAlreadyApplied = db.JobsApplieds.Where(a => a.Username == Username && a.JobId == JobId).ToList();
            if (isAlreadyApplied.Count == 0)
            {
                try
                {
                    JobsApplied newjob = new JobsApplied()
                    {
                        JobId = JobId,
                        Username = Username,
                        AppliedDate = DateTime.Now.Date
                    };
                    db.JobsApplieds.Add(newjob);
                    db.SaveChanges();
                    return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
                }
                catch (Exception e)
                {
                    return Json(new { status = "failed", error = e.Message.ToString() }, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                return Json(new { status = "failed", error = "This Job is Already applied by this username" }, JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult AppliedJobs(int? page)
        {
            string username = Session["Username"].ToString();
            var query = from l in db.JobsApplieds
                        where l.Username == username
                        select l;
            return View(query.ToList().ToPagedList(page ?? 1, 3));

            //List<JobsApplied> li = db.JobsApplieds.ToList();
            //return View(li);

        }

        public ActionResult EditMyDetails()
        {
            string username = Session["Username"].ToString();
            var studentdetails = db.StudentDetails.Where(a => a.Username == username).SingleOrDefault();
            if (studentdetails != null)
            {
                ViewBag.dob = studentdetails.DOB;
                return View(studentdetails);
            }
            return View();

        }

        [HttpPost]
        public ActionResult EditMyDetails(StudentDetail obj)
        {
            if (ModelState.IsValid)
            {
                db.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return Content("<html><body><script>alert('Successfully Edited'); window.location.href = '/Student/StudentRoles';</script></body></html>");
                //return RedirectToAction("StudentRoles");
            }
            return View();
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            return RedirectToAction("Index", "Home");

        }

        [HttpPost]
        public JsonResult IsUserNameAvailable(string Username)
        {
            return Json(IsUserAvailable(Username));
        }

        public bool IsUserAvailable(string Username)
        {
            bool isExists = true;
            var ex = db.StudentDetails.Where(a => a.Username == Username).SingleOrDefault();
            if (ex != null)
            {
                isExists = false;
            }
            return isExists;
        }
        
        [HttpPost]
        public JsonResult IsEmailAvailable(string EmailId)
        {
            return Json(Isemailexists(EmailId));
        }

        public bool Isemailexists(string email)
        {
            bool status = true;
            var ex = db.StudentDetails.Where(a => a.EmailId.ToUpper() == email.ToUpper()).FirstOrDefault();
            if (ex != null)
            {
                status = false;
                return status;
            }
            return status;
        }

        [HttpPost]
        public JsonResult IsMobileNumberAvailable(long PhoneNumber)
        {
            return Json(Isnumberexists(PhoneNumber));
        }

        public bool Isnumberexists(long phoneno)
        {
            bool status = true;
            var ex = db.StudentDetails.Where(a => a.PhoneNumber == phoneno).FirstOrDefault();
            if (ex != null)
            {
                status = false;
                return status;
            }
            return status;
        }

        [HttpGet]
        public ActionResult GetJobs()
        {
            var res = (from a in db.Jobs select new { jobid = a.JobId, jobtitle= a.JobTitle, companyname=a.CompanyName, jobdesc = a.JobDescription, createddate = a.CreatedDate }).ToList();
            return Json(new { data = res }, JsonRequestBehavior.AllowGet);
        } 
        
        [HttpGet]
        public ActionResult GetAppliedJobs()
        {
            string username = Session["Username"].ToString();
            var res = (from a in db.JobsApplieds where a.Username == username select new { jobtitle = a.Job.JobTitle, username= a.Username, companyname=a.Job.CompanyName, applieddate = a.AppliedDate }).ToList();
            return Json(new { data = res }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeleteJobById(int? jobid)
        {
            var job = db.Jobs.Find(jobid);
            db.Jobs.Remove(job);
            db.SaveChanges();
            return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
        }       
    }
}
