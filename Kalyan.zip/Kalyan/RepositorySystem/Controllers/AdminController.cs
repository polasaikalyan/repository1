﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RepositorySystem.Models;
using PagedList;
using PagedList.Mvc;

namespace RepositorySystem.Controllers
{
    public class AdminController : Controller
    {
        Training_20March_CloudChennaiEntities4 db = new Training_20March_CloudChennaiEntities4();
        // GET: Admin

        [HttpGet]
        public ActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AdminLogin(AdminDetail L)
        {
            if (L.Username == "Admin")
            {
                if (L.Password == "Admin")
                {
                    Session["role"] = "admin";
                    return RedirectToAction("AdminRoles");
                }
                ModelState.AddModelError("password", "Incorrect Password");
            }
            else
            {
                ModelState.AddModelError("username", "Username Not Found");
            }
            return View();
        }
        [HttpGet]
        public ActionResult AdminRoles()
        {
            return View();
        }

        public ActionResult ManageStudents()
        {
            //List<StudentDetail> b = db.StudentDetails.ToList();
            //return View(b.ToList().ToPagedList(page?? 1,3));
            return View();
        }

        public ActionResult ManageJobs()
        {
            //List<StudentDetail> b = db.StudentDetails.ToList();
            //return View(b.ToList().ToPagedList(page?? 1,3));
            return View();
        }

        [HttpGet]
        public ActionResult CreateJobs()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateJobs(Job j)
        {
            if (ModelState.IsValid)
            {
                j.CreatedDate = DateTime.Now;
                db.Jobs.Add(j);
                db.SaveChanges();
                return Content("<html><body><script>alert('Successfully Added'); window.location.href = '/Admin/AdminRoles';</script></body></html>");
            }
            return View();
        }
        public ActionResult JobsAdded()
        {
            return View();
        }
        // GET: Bookings/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentDetail sd = db.StudentDetails.Find(id);
            if (sd == null)
            {
                return HttpNotFound();
            }
            return View(sd);
        }

        // POST: Bookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            StudentDetail sd = db.StudentDetails.Find(id);
            db.StudentDetails.Remove(sd);
            db.SaveChanges();
            return RedirectToAction("ManageStudents");
        }
        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index", "Home");
           
        }

        [HttpGet]
        public ActionResult GetStudents()
        {
            var res = (from a in db.StudentDetails select new { studentid = a.StudentId, studentname = a.StudentName, dob = a.DOB, gender = a.Gender,  mobilenumber = a.PhoneNumber, address = a.Address, email=a.EmailId }).ToList();
            return Json(new { data = res }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeleteStudentById(int? studentid)
        {
            var student = db.StudentDetails.Find(studentid);
            db.StudentDetails.Remove(student);          
            db.SaveChanges();
            return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
        }



        [HttpGet]
        public ActionResult GetJobs()
        {
            var res = (from a in db.Jobs select new { jobid = a.JobId, jobtitle = a.JobTitle, companyname = a.CompanyName, jobdesc = a.JobDescription, createddate = a.CreatedDate }).ToList();
            return Json(new { data = res }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteJobById(int? jobid)
        {
            var job = db.Jobs.Find(jobid);
            db.Jobs.Remove(job);
            db.SaveChanges();
            return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
        }
    }
}