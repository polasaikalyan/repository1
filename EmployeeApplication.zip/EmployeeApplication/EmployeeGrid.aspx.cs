﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace EmployeeApplication
{
    public partial class EmployeeGrid : System.Web.UI.Page
    {
         string str = ConfigurationManager.ConnectionStrings["MyDB"].ConnectionString;
        //static string str = "server = ndamssql\\sqlilearn; database = Training_20March_CloudChennai; Integrated Security = false; user id = sqluser; password = sqluser";    
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                refreshdata();
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddNewEmployee.aspx");
        }
        public void refreshdata()
        {
            SqlConnection con = new SqlConnection(str);
            SqlCommand sc = new SqlCommand("kaly.display", con);
            sc.CommandType = CommandType.StoredProcedure;
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(sc);
            da.Fill(ds);
            GridView1.DataSource = ds; 
            GridView1.DataBind();
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditButton")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];
                Session["type"] = "update";
                Response.Redirect("~/AddNewEmployee.aspx?EmpId=" + row.Cells[1].Text);
            }
            if(e.CommandName == "DeleteButton") {
                //string str = "server = ndamssql\\sqlilearn; database = Training_20March_CloudChennai; Integrated Security = false; user id = sqluser; password = sqluser";
                SqlConnection con = new SqlConnection(str);
                try
                {
                    SqlCommand sc = new SqlCommand("kaly.Employee_delete", con);
                    sc.CommandType = CommandType.StoredProcedure;
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = GridView1.Rows[index];
                    sc.Parameters.AddWithValue("@EmployeeId", Convert.ToInt32(row.Cells[1].Text));
                    con.Open();
                    sc.ExecuteNonQuery();
                    Response.Write("One row deleted");
                    con.Close();
                    Response.Redirect("EmployeeGrid.aspx");
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message.ToString());
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}